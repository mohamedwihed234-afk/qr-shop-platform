import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import slugify from 'slugify';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateSlug(name: string): string {
  // Transliterate common Arabic to Latin for better URLs
  const arabicMap: Record<string, string> = {
    'ا': 'a', 'أ': 'a', 'إ': 'i', 'آ': 'a',
    'ب': 'b', 'ت': 't', 'ث': 'th', 'ج': 'j',
    'ح': 'h', 'خ': 'kh', 'د': 'd', 'ذ': 'dh',
    'ر': 'r', 'ز': 'z', 'س': 's', 'ش': 'sh',
    'ص': 's', 'ض': 'd', 'ط': 't', 'ظ': 'z',
    'ع': 'a', 'غ': 'gh', 'ف': 'f', 'ق': 'q',
    'ك': 'k', 'ل': 'l', 'م': 'm', 'ن': 'n',
    'ه': 'h', 'و': 'w', 'ي': 'y', 'ى': 'a',
    'ة': 'h', 'ء': '', 'ؤ': 'w', 'ئ': 'y',
    ' ': '-',
  };

  let result = name.trim().toLowerCase();
  result = result.split('').map(char => arabicMap[char] || char).join('');
  
  return slugify(result, {
    lower: true,
    strict: true,
    locale: 'en',
  }) || 'shop';
}

export function getDeviceType(userAgent: string | null): string {
  if (!userAgent) return 'unknown';
  const ua = userAgent.toLowerCase();
  if (/mobile|android|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(ua)) {
    return 'mobile';
  }
  if (/tablet|ipad/i.test(ua)) {
    return 'tablet';
  }
  return 'desktop';
}

export function formatWhatsAppLink(phone: string): string {
  // Remove non-digits
  let cleaned = phone.replace(/\D/g, '');
  // If starts with 0, assume Libya (+218)
  if (cleaned.startsWith('0')) {
    cleaned = '218' + cleaned.slice(1);
  }
  // If no country code, add Libya
  if (cleaned.length <= 10) {
    cleaned = '218' + cleaned;
  }
  return `https://wa.me/${cleaned}`;
}

export function formatPhoneLink(phone: string): string {
  let cleaned = phone.replace(/\D/g, '');
  if (cleaned.startsWith('0')) {
    cleaned = '+218' + cleaned.slice(1);
  } else if (!cleaned.startsWith('+') && !cleaned.startsWith('218')) {
    cleaned = '+218' + cleaned;
  } else if (cleaned.startsWith('218')) {
    cleaned = '+' + cleaned;
  }
  return `tel:${cleaned}`;
}

export function getAppUrl(): string {
  if (typeof window !== 'undefined') {
    return window.location.origin;
  }
  return process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
}
