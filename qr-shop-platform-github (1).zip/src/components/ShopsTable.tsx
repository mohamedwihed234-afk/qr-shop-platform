'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ExternalLink,
  Pencil,
  Trash2,
  QrCode,
  Copy,
  Power,
  PowerOff,
  Check,
} from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import type { Shop } from '@/types';
import { getAppUrl } from '@/lib/utils';

interface ShopWithViews extends Shop {
  page_views: number;
}

interface Props {
  shops: ShopWithViews[];
}

export function ShopsTable({ shops: initialShops }: Props) {
  const [shops, setShops] = useState(initialShops);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [loading, setLoading] = useState<string | null>(null);
  const router = useRouter();
  const supabase = createClient();

  async function toggleStatus(shop: ShopWithViews) {
    setLoading(shop.id);
    const newStatus = shop.status === 'active' ? 'inactive' : 'active';
    const { error } = await supabase
      .from('shops')
      .update({ status: newStatus })
      .eq('id', shop.id);

    if (!error) {
      setShops((prev) =>
        prev.map((s) =>
          s.id === shop.id ? { ...s, status: newStatus } : s
        )
      );
    }
    setLoading(null);
  }

  async function deleteShop(shop: ShopWithViews) {
    if (!confirm(`هل أنت متأكد من حذف "${shop.name}"؟`)) return;
    setLoading(shop.id);
    const { error } = await supabase.from('shops').delete().eq('id', shop.id);
    if (!error) {
      setShops((prev) => prev.filter((s) => s.id !== shop.id));
    }
    setLoading(null);
  }

  function copyLink(shop: ShopWithViews) {
    const url = `${getAppUrl()}/shop/${shop.slug}`;
    navigator.clipboard.writeText(url);
    setCopiedId(shop.id);
    setTimeout(() => setCopiedId(null), 2000);
  }

  if (shops.length === 0) {
    return (
      <div className="bg-white rounded-2xl border border-slate-100 p-12 text-center">
        <p className="text-slate-500 mb-4">لا توجد محلات بعد</p>
        <Link
          href="/admin/shops/new"
          className="inline-flex items-center gap-2 bg-teal-600 text-white px-5 py-2.5 rounded-xl font-medium"
        >
          إضافة أول محل
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl border border-slate-100 overflow-hidden shadow-sm">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-100">
              <th className="text-right px-4 py-3 font-semibold text-slate-600">الاسم</th>
              <th className="text-right px-4 py-3 font-semibold text-slate-600 hidden sm:table-cell">الرابط</th>
              <th className="text-center px-4 py-3 font-semibold text-slate-600">الزيارات</th>
              <th className="text-center px-4 py-3 font-semibold text-slate-600">الحالة</th>
              <th className="text-center px-4 py-3 font-semibold text-slate-600">الإجراءات</th>
            </tr>
          </thead>
          <tbody>
            {shops.map((shop) => (
              <tr
                key={shop.id}
                className="border-b border-slate-50 hover:bg-slate-50/50 transition"
              >
                <td className="px-4 py-3">
                  <div className="font-medium text-slate-900">{shop.name}</div>
                  <div className="text-xs text-slate-400 mt-0.5 sm:hidden">
                    /shop/{shop.slug}
                  </div>
                </td>
                <td className="px-4 py-3 hidden sm:table-cell">
                  <code className="text-xs bg-slate-100 px-2 py-1 rounded text-slate-600">
                    /shop/{shop.slug}
                  </code>
                </td>
                <td className="px-4 py-3 text-center font-medium text-slate-700">
                  {shop.page_views}
                </td>
                <td className="px-4 py-3 text-center">
                  <span
                    className={`inline-block px-2.5 py-1 rounded-full text-xs font-medium ${
                      shop.status === 'active'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    {shop.status === 'active' ? 'نشط' : 'معطل'}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-center gap-1 flex-wrap">
                    <Link
                      href={`/shop/${shop.slug}`}
                      target="_blank"
                      className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-teal-600 transition"
                      title="فتح الصفحة"
                    >
                      <ExternalLink size={16} />
                    </Link>
                    <Link
                      href={`/admin/shops/${shop.id}`}
                      className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-blue-600 transition"
                      title="تعديل"
                    >
                      <Pencil size={16} />
                    </Link>
                    <Link
                      href={`/admin/qr/${shop.slug}`}
                      className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-purple-600 transition"
                      title="عرض QR"
                    >
                      <QrCode size={16} />
                    </Link>
                    <button
                      onClick={() => copyLink(shop)}
                      className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-indigo-600 transition"
                      title="نسخ الرابط"
                    >
                      {copiedId === shop.id ? (
                        <Check size={16} className="text-green-600" />
                      ) : (
                        <Copy size={16} />
                      )}
                    </button>
                    <button
                      onClick={() => toggleStatus(shop)}
                      disabled={loading === shop.id}
                      className="p-2 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-amber-600 transition"
                      title={shop.status === 'active' ? 'تعطيل' : 'تفعيل'}
                    >
                      {shop.status === 'active' ? (
                        <PowerOff size={16} />
                      ) : (
                        <Power size={16} />
                      )}
                    </button>
                    <button
                      onClick={() => deleteShop(shop)}
                      disabled={loading === shop.id}
                      className="p-2 rounded-lg hover:bg-red-50 text-slate-500 hover:text-red-600 transition"
                      title="حذف"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
