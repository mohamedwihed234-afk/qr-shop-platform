export type ShopStatus = 'active' | 'inactive';

export type EventType =
  | 'page_view'
  | 'google_click'
  | 'whatsapp_click'
  | 'phone_click'
  | 'instagram_click'
  | 'facebook_click'
  | 'snapchat_click'
  | 'tiktok_click'
  | 'maps_click'
  | 'menu_click';

export interface Shop {
  id: string;
  slug: string;
  name: string;
  logo_url: string | null;
  cover_url: string | null;
  description: string | null;
  phone: string | null;
  whatsapp: string | null;
  instagram_url: string | null;
  facebook_url: string | null;
  snapchat_url: string | null;
  tiktok_url: string | null;
  google_maps_url: string | null;
  google_review_url: string | null;
  menu_url: string | null;
  address: string | null;
  opening_hours: string | null;
  primary_color: string;
  secondary_color: string;
  status: ShopStatus;
  created_at: string;
  updated_at: string;
}

export interface AnalyticsEvent {
  id: string;
  shop_id: string;
  event_type: EventType;
  device_type: string | null;
  created_at: string;
}

export interface ShopFormData {
  name: string;
  logo_url?: string;
  cover_url?: string;
  description?: string;
  phone?: string;
  whatsapp?: string;
  instagram_url?: string;
  facebook_url?: string;
  snapchat_url?: string;
  tiktok_url?: string;
  google_maps_url?: string;
  google_review_url?: string;
  menu_url?: string;
  address?: string;
  opening_hours?: string;
  primary_color?: string;
  secondary_color?: string;
  status?: ShopStatus;
}

export interface DashboardStats {
  totalShops: number;
  totalPageViews: number;
  totalGoogleClicks: number;
  totalWhatsappClicks: number;
  totalInstagramClicks: number;
  totalFacebookClicks: number;
  totalSnapchatClicks: number;
  totalTiktokClicks: number;
  totalPhoneClicks: number;
  totalMapsClicks: number;
  totalMenuClicks: number;
  todayViews: number;
  last7DaysViews: number;
  last30DaysViews: number;
}

export interface ShopWithStats extends Shop {
  page_views: number;
  total_clicks: number;
}
