import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import type { EventType } from '@/types';

const VALID_EVENTS: EventType[] = [
  'page_view',
  'google_click',
  'whatsapp_click',
  'phone_click',
  'instagram_click',
  'facebook_click',
  'snapchat_click',
  'tiktok_click',
  'maps_click',
  'menu_click',
];

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { shop_id, event_type, device_type } = body;

    if (!shop_id || !event_type || !VALID_EVENTS.includes(event_type)) {
      return NextResponse.json({ error: 'Invalid data' }, { status: 400 });
    }

    const supabase = await createClient();

    const { error } = await supabase.from('analytics_events').insert({
      shop_id,
      event_type,
      device_type: device_type || null,
    });

    if (error) {
      console.error('Analytics error:', error);
      return NextResponse.json({ error: 'Failed to track' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
