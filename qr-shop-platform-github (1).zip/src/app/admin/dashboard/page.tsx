import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import {
  Store,
  Eye,
  Star,
  MessageCircle,
  Phone,
  Instagram,
  Facebook,
  MapPin,
  Menu,
  Camera,
  Music2,
  Plus,
  LayoutDashboard,
} from 'lucide-react';
import { AdminHeader } from '@/components/AdminHeader';
import type { DashboardStats } from '@/types';

async function getStats(): Promise<DashboardStats> {
  const supabase = await createClient();

  const { count: totalShops } = await supabase
    .from('shops')
    .select('*', { count: 'exact', head: true });

  const { data: events } = await supabase
    .from('analytics_events')
    .select('event_type, created_at');

  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const last7 = new Date(todayStart);
  last7.setDate(last7.getDate() - 7);
  const last30 = new Date(todayStart);
  last30.setDate(last30.getDate() - 30);

  const counts: Record<string, number> = {};
  let todayViews = 0;
  let last7DaysViews = 0;
  let last30DaysViews = 0;

  (events || []).forEach((e) => {
    counts[e.event_type] = (counts[e.event_type] || 0) + 1;
    if (e.event_type === 'page_view') {
      const d = new Date(e.created_at);
      if (d >= todayStart) todayViews++;
      if (d >= last7) last7DaysViews++;
      if (d >= last30) last30DaysViews++;
    }
  });

  return {
    totalShops: totalShops || 0,
    totalPageViews: counts['page_view'] || 0,
    totalGoogleClicks: counts['google_click'] || 0,
    totalWhatsappClicks: counts['whatsapp_click'] || 0,
    totalInstagramClicks: counts['instagram_click'] || 0,
    totalFacebookClicks: counts['facebook_click'] || 0,
    totalSnapchatClicks: counts['snapchat_click'] || 0,
    totalTiktokClicks: counts['tiktok_click'] || 0,
    totalPhoneClicks: counts['phone_click'] || 0,
    totalMapsClicks: counts['maps_click'] || 0,
    totalMenuClicks: counts['menu_click'] || 0,
    todayViews,
    last7DaysViews,
    last30DaysViews,
  };
}

export default async function DashboardPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect('/admin/login');

  const stats = await getStats();

  const cards = [
    { label: 'عدد المحلات', value: stats.totalShops, icon: Store, color: 'bg-teal-500' },
    { label: 'إجمالي الزيارات', value: stats.totalPageViews, icon: Eye, color: 'bg-blue-500' },
    { label: 'زيارات اليوم', value: stats.todayViews, icon: Eye, color: 'bg-indigo-500' },
    { label: 'آخر 7 أيام', value: stats.last7DaysViews, icon: Eye, color: 'bg-violet-500' },
    { label: 'آخر 30 يوم', value: stats.last30DaysViews, icon: Eye, color: 'bg-purple-500' },
    { label: 'نقرات Google', value: stats.totalGoogleClicks, icon: Star, color: 'bg-amber-500' },
    { label: 'نقرات واتساب', value: stats.totalWhatsappClicks, icon: MessageCircle, color: 'bg-green-500' },
    { label: 'نقرات الاتصال', value: stats.totalPhoneClicks, icon: Phone, color: 'bg-sky-500' },
    { label: 'نقرات إنستغرام', value: stats.totalInstagramClicks, icon: Instagram, color: 'bg-pink-500' },
    { label: 'نقرات فيسبوك', value: stats.totalFacebookClicks, icon: Facebook, color: 'bg-blue-600' },
    { label: 'نقرات سناب', value: stats.totalSnapchatClicks, icon: Camera, color: 'bg-yellow-400' },
    { label: 'نقرات تيك توك', value: stats.totalTiktokClicks, icon: Music2, color: 'bg-slate-800' },
    { label: 'نقرات الخريطة', value: stats.totalMapsClicks, icon: MapPin, color: 'bg-red-500' },
    { label: 'نقرات المنيو', value: stats.totalMenuClicks, icon: Menu, color: 'bg-violet-600' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <AdminHeader />

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <LayoutDashboard size={28} className="text-teal-600" />
              لوحة التحكم
            </h1>
            <p className="text-slate-500 text-sm mt-1">نظرة عامة على الأداء</p>
          </div>
          <Link
            href="/admin/shops/new"
            className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold px-5 py-3 rounded-xl transition shadow-sm"
          >
            <Plus size={20} />
            إضافة محل جديد
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.label}
                className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 hover:shadow-md transition"
              >
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-10 h-10 ${card.color} rounded-xl flex items-center justify-center`}>
                    <Icon size={20} className="text-white" />
                  </div>
                </div>
                <p className="text-2xl font-bold text-slate-900">{card.value}</p>
                <p className="text-xs text-slate-500 mt-1">{card.label}</p>
              </div>
            );
          })}
        </div>

        <div className="mt-8">
          <Link
            href="/admin/shops"
            className="inline-flex items-center gap-2 text-teal-600 hover:text-teal-700 font-medium"
          >
            <Store size={18} />
            عرض جميع المحلات ←
          </Link>
        </div>
      </main>
    </div>
  );
}
