'use client';

import { useEffect, useState, useRef } from 'react';
import { useParams } from 'next/navigation';
import { QRCodeCanvas, QRCodeSVG } from 'qrcode.react';
import { createClient } from '@/lib/supabase/client';
import { AdminHeader } from '@/components/AdminHeader';
import { Download, Printer, Copy, Check, ExternalLink, Loader2 } from 'lucide-react';
import Link from 'next/link';
import type { Shop } from '@/types';
import { getAppUrl } from '@/lib/utils';

export default function QRPage() {
  const params = useParams();
  const slug = params.slug as string;
  const [shop, setShop] = useState<Shop | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);
  const supabase = createClient();

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from('shops')
        .select('*')
        .eq('slug', slug)
        .single();
      setShop(data);
      setLoading(false);
    }
    load();
  }, [slug]);

  const url = shop ? `${getAppUrl()}/shop/${shop.slug}` : '';

  function downloadPNG() {
    const canvas = canvasRef.current?.querySelector('canvas');
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `qr-${shop?.slug || 'shop'}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }

  function downloadSVG() {
    const svg = document.getElementById('qr-svg');
    if (!svg) return;
    const data = new XMLSerializer().serializeToString(svg);
    const blob = new Blob([data], { type: 'image/svg+xml' });
    const link = document.createElement('a');
    link.download = `qr-${shop?.slug || 'shop'}.svg`;
    link.href = URL.createObjectURL(blob);
    link.click();
  }

  function copyUrl() {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="animate-spin text-teal-600" size={32} />
      </div>
    );
  }

  if (!shop) {
    return (
      <div className="min-h-screen bg-slate-50">
        <AdminHeader />
        <div className="text-center py-20 text-slate-500">المحل غير موجود</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <AdminHeader />

      <main className="max-w-lg mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-slate-900 mb-2 text-center">
          QR Code — {shop.name}
        </h1>
        <p className="text-center text-slate-500 text-sm mb-8 dir-ltr">
          {url}
        </p>

        {/* QR Display */}
        <div className="bg-white rounded-3xl shadow-lg border border-slate-100 p-8 flex flex-col items-center">
          <div ref={canvasRef} className="bg-white p-4 rounded-2xl">
            <QRCodeCanvas
              value={url}
              size={280}
              level="H"
              includeMargin
              bgColor="#ffffff"
              fgColor="#0f172a"
            />
          </div>

          {/* Hidden SVG for download */}
          <div className="hidden">
            <QRCodeSVG
              id="qr-svg"
              value={url}
              size={512}
              level="H"
              includeMargin
            />
          </div>

          <p className="text-sm text-slate-500 mt-4 text-center">
            امسح الكود لفتح صفحة المحل
          </p>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3 mt-6">
          <button
            onClick={downloadPNG}
            className="flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 rounded-xl transition"
          >
            <Download size={18} />
            تحميل PNG
          </button>
          <button
            onClick={downloadSVG}
            className="flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 rounded-xl transition"
          >
            <Download size={18} />
            تحميل SVG
          </button>
          <Link
            href={`/print/${shop.slug}`}
            target="_blank"
            className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-900 text-white font-semibold py-3 rounded-xl transition"
          >
            <Printer size={18} />
            صفحة الطباعة
          </Link>
          <button
            onClick={copyUrl}
            className="flex items-center justify-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-3 rounded-xl transition"
          >
            {copied ? <Check size={18} className="text-green-600" /> : <Copy size={18} />}
            {copied ? 'تم النسخ' : 'نسخ الرابط'}
          </button>
        </div>

        <div className="mt-4 text-center">
          <Link
            href={`/shop/${shop.slug}`}
            target="_blank"
            className="inline-flex items-center gap-1 text-teal-600 hover:underline text-sm"
          >
            <ExternalLink size={14} />
            فتح صفحة المحل
          </Link>
        </div>
      </main>
    </div>
  );
}
