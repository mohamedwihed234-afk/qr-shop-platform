'use client';

import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { AdminHeader } from '@/components/AdminHeader';
import { Loader2, Save, ArrowRight } from 'lucide-react';
import Link from 'next/link';
import type { Shop } from '@/types';

export default function EditShopPage() {
  const params = useParams();
  const id = params.id as string;
  const router = useRouter();
  const supabase = createClient();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [form, setForm] = useState<Partial<Shop>>({});

  useEffect(() => {
    async function load() {
      const { data, error } = await supabase
        .from('shops')
        .select('*')
        .eq('id', id)
        .single();

      if (error || !data) {
        setError('المحل غير موجود');
        setLoading(false);
        return;
      }
      setForm(data);
      setLoading(false);
    }
    load();
  }, [id]);

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name?.trim()) {
      setError('اسم المحل مطلوب');
      return;
    }

    setSaving(true);
    setError('');
    setSuccess(false);

    const payload = {
      name: form.name.trim(),
      logo_url: form.logo_url || null,
      cover_url: form.cover_url || null,
      description: form.description || null,
      phone: form.phone || null,
      whatsapp: form.whatsapp || null,
      instagram_url: form.instagram_url || null,
      facebook_url: form.facebook_url || null,
      snapchat_url: form.snapchat_url || null,
      tiktok_url: form.tiktok_url || null,
      google_maps_url: form.google_maps_url || null,
      google_review_url: form.google_review_url || null,
      menu_url: form.menu_url || null,
      address: form.address || null,
      opening_hours: form.opening_hours || null,
      primary_color: form.primary_color || '#0f766e',
      secondary_color: form.secondary_color || '#14b8a6',
      status: form.status || 'active',
    };

    const { error: updateError } = await supabase
      .from('shops')
      .update(payload)
      .eq('id', id);

    if (updateError) {
      setError(updateError.message);
      setSaving(false);
      return;
    }

    setSuccess(true);
    setSaving(false);
    setTimeout(() => setSuccess(false), 3000);
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="animate-spin text-teal-600" size={32} />
      </div>
    );
  }

  const fields = [
    { name: 'name', label: 'اسم المحل *', required: true },
    { name: 'description', label: 'وصف قصير', type: 'textarea' },
    { name: 'whatsapp', label: 'رقم الواتساب', dir: 'ltr' },
    { name: 'phone', label: 'رقم الهاتف', dir: 'ltr' },
    { name: 'snapchat_url', label: 'رابط سناب شات', dir: 'ltr' },
    { name: 'tiktok_url', label: 'رابط تيك توك', dir: 'ltr' },
    { name: 'instagram_url', label: 'رابط إنستغرام', dir: 'ltr' },
    { name: 'facebook_url', label: 'رابط فيسبوك', dir: 'ltr' },
    { name: 'google_maps_url', label: 'رابط Google Maps', dir: 'ltr' },
    { name: 'google_review_url', label: 'رابط تقييم Google', dir: 'ltr' },
    { name: 'menu_url', label: 'رابط المنيو', dir: 'ltr' },
    { name: 'address', label: 'العنوان' },
    { name: 'opening_hours', label: 'أوقات العمل' },
    { name: 'logo_url', label: 'رابط الشعار', dir: 'ltr' },
    { name: 'cover_url', label: 'رابط صورة الغلاف', dir: 'ltr' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <AdminHeader />

      <main className="max-w-2xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link
            href="/admin/shops"
            className="p-2 rounded-lg hover:bg-slate-200 transition"
          >
            <ArrowRight size={20} />
          </Link>
          <h1 className="text-2xl font-bold text-slate-900">تعديل المحل</h1>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-5"
        >
          <p className="text-sm text-slate-500 bg-amber-50 text-amber-800 px-4 py-3 rounded-xl">
            تغيير البيانات يحدّث الصفحة فوراً دون تغيير الـ QR Code.
          </p>

          {fields.map((f) => (
            <div key={f.name}>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                {f.label}
              </label>
              {f.type === 'textarea' ? (
                <textarea
                  name={f.name}
                  value={(form as any)[f.name] || ''}
                  onChange={handleChange}
                  rows={3}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition resize-none"
                />
              ) : (
                <input
                  type="text"
                  name={f.name}
                  value={(form as any)[f.name] || ''}
                  onChange={handleChange}
                  required={f.required}
                  dir={f.dir as any}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition"
                />
              )}
            </div>
          ))}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                اللون الرئيسي
              </label>
              <input
                type="color"
                name="primary_color"
                value={form.primary_color || '#0f766e'}
                onChange={handleChange}
                className="w-full h-12 rounded-xl border border-slate-200 cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                اللون الثانوي
              </label>
              <input
                type="color"
                name="secondary_color"
                value={form.secondary_color || '#14b8a6'}
                onChange={handleChange}
                className="w-full h-12 rounded-xl border border-slate-200 cursor-pointer"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              الحالة
            </label>
            <select
              name="status"
              value={form.status || 'active'}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-teal-500 outline-none"
            >
              <option value="active">نشط</option>
              <option value="inactive">معطل</option>
            </select>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 text-sm px-4 py-3 rounded-xl">
              {error}
            </div>
          )}
          {success && (
            <div className="bg-green-50 text-green-700 text-sm px-4 py-3 rounded-xl">
              تم الحفظ بنجاح ✓
            </div>
          )}

          <button
            type="submit"
            disabled={saving}
            className="w-full flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold py-4 rounded-xl transition disabled:opacity-60"
          >
            {saving ? (
              <Loader2 className="animate-spin" size={22} />
            ) : (
              <>
                <Save size={20} />
                حفظ التعديلات
              </>
            )}
          </button>
        </form>
      </main>
    </div>
  );
}
