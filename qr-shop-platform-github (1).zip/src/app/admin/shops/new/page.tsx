'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { AdminHeader } from '@/components/AdminHeader';
import { generateSlug } from '@/lib/utils';
import { Loader2, Store, CheckCircle } from 'lucide-react';
import Link from 'next/link';

export default function NewShopPage() {
  const router = useRouter();
  const supabase = createClient();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState<{
    id: string;
    name: string;
    slug: string;
  } | null>(null);

  const [form, setForm] = useState({
    name: '',
    logo_url: '',
    cover_url: '',
    description: '',
    phone: '',
    whatsapp: '',
    instagram_url: '',
    facebook_url: '',
    snapchat_url: '',
    tiktok_url: '',
    google_maps_url: '',
    google_review_url: '',
    menu_url: '',
    address: '',
    opening_hours: '',
    primary_color: '#0f766e',
    secondary_color: '#14b8a6',
  });

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.name.trim()) {
      setError('اسم المحل مطلوب');
      return;
    }

    setLoading(true);
    setError('');

    let slug = generateSlug(form.name);
    // Check uniqueness
    const { data: existing } = await supabase
      .from('shops')
      .select('slug')
      .eq('slug', slug)
      .maybeSingle();

    if (existing) {
      slug = `${slug}-${Date.now().toString().slice(-4)}`;
    }

    const payload = {
      name: form.name.trim(),
      slug,
      logo_url: form.logo_url || null,
      cover_url: form.cover_url || null,
      description: form.description || null,
      phone: form.phone || null,
      whatsapp: form.whatsapp || null,
      instagram_url: form.instagram_url || null,
      facebook_url: form.facebook_url || null,
      snapchat_url: form.snapchat_url || null,
      tiktok_url: form.tiktok_url || null,
      google_maps_url: form.google_maps_url || null,
      google_review_url: form.google_review_url || null,
      menu_url: form.menu_url || null,
      address: form.address || null,
      opening_hours: form.opening_hours || null,
      primary_color: form.primary_color,
      secondary_color: form.secondary_color,
      status: 'active',
    };

    const { data, error: insertError } = await supabase
      .from('shops')
      .insert(payload)
      .select('id, name, slug')
      .single();

    if (insertError) {
      setError(insertError.message || 'حدث خطأ أثناء الإنشاء');
      setLoading(false);
      return;
    }

    setSuccess(data);
    setLoading(false);
  }

  if (success) {
    return (
      <div className="min-h-screen bg-slate-50">
        <AdminHeader />
        <main className="max-w-lg mx-auto px-4 py-16 text-center">
          <div className="bg-white rounded-3xl shadow-lg p-8 border border-slate-100">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="text-green-600" size={32} />
            </div>
            <h1 className="text-2xl font-bold text-slate-900 mb-2">
              تم إنشاء المحل بنجاح ✅
            </h1>
            <p className="text-lg text-slate-700 mb-1">{success.name}</p>
            <p className="text-sm text-slate-500 mb-6 dir-ltr">
              /shop/{success.slug}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Link
                href={`/shop/${success.slug}`}
                target="_blank"
                className="bg-teal-600 hover:bg-teal-700 text-white font-semibold py-3 rounded-xl transition"
              >
                فتح الصفحة
              </Link>
              <Link
                href={`/admin/qr/${success.slug}`}
                className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 rounded-xl transition"
              >
                عرض QR
              </Link>
              <Link
                href={`/admin/shops/${success.id}`}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-3 rounded-xl transition"
              >
                تعديل المحل
              </Link>
              <Link
                href="/admin/shops/new"
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-3 rounded-xl transition"
              >
                إضافة محل آخر
              </Link>
            </div>
          </div>
        </main>
      </div>
    );
  }

  const fields = [
    { name: 'name', label: 'اسم المحل *', required: true, placeholder: 'مثال: مطعم النخبة' },
    { name: 'description', label: 'وصف قصير', type: 'textarea', placeholder: 'وصف المحل...' },
    { name: 'whatsapp', label: 'رقم الواتساب', placeholder: '0912345678', dir: 'ltr' },
    { name: 'phone', label: 'رقم الهاتف', placeholder: '0912345678', dir: 'ltr' },
    { name: 'snapchat_url', label: 'رابط سناب شات', placeholder: 'https://snapchat.com/add/...', dir: 'ltr' },
    { name: 'tiktok_url', label: 'رابط تيك توك', placeholder: 'https://tiktok.com/@...', dir: 'ltr' },
    { name: 'instagram_url', label: 'رابط إنستغرام', placeholder: 'https://instagram.com/...', dir: 'ltr' },
    { name: 'facebook_url', label: 'رابط فيسبوك', placeholder: 'https://facebook.com/...', dir: 'ltr' },
    { name: 'google_maps_url', label: 'رابط Google Maps', placeholder: 'https://maps.google.com/...', dir: 'ltr' },
    { name: 'google_review_url', label: 'رابط تقييم Google', placeholder: 'https://g.page/r/...', dir: 'ltr' },
    { name: 'menu_url', label: 'رابط المنيو', placeholder: 'https://... أو رابط PDF', dir: 'ltr' },
    { name: 'address', label: 'العنوان', placeholder: 'طرابلس، ليبيا' },
    { name: 'opening_hours', label: 'أوقات العمل', placeholder: 'يومياً 10 ص – 12 م' },
    { name: 'logo_url', label: 'رابط الشعار (Logo)', placeholder: 'https://...', dir: 'ltr' },
    { name: 'cover_url', label: 'رابط صورة الغلاف', placeholder: 'https://...', dir: 'ltr' },
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      <AdminHeader />

      <main className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2 mb-6">
          <Store size={28} className="text-teal-600" />
          إضافة محل جديد
        </h1>

        <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-5">
          <p className="text-sm text-slate-500 bg-teal-50 text-teal-800 px-4 py-3 rounded-xl">
            جميع الحقول اختيارية ما عدا اسم المحل. إذا لم تدخل رابطاً فلن يظهر الزر في صفحة المحل.
          </p>

          {fields.map((f) => (
            <div key={f.name}>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                {f.label}
              </label>
              {f.type === 'textarea' ? (
                <textarea
                  name={f.name}
                  value={(form as any)[f.name]}
                  onChange={handleChange}
                  rows={3}
                  placeholder={f.placeholder}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition resize-none"
                />
              ) : (
                <input
                  type="text"
                  name={f.name}
                  value={(form as any)[f.name]}
                  onChange={handleChange}
                  required={f.required}
                  placeholder={f.placeholder}
                  dir={f.dir as any}
                  className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-teal-500 focus:ring-2 focus:ring-teal-500/20 outline-none transition"
                />
              )}
            </div>
          ))}

          {/* Colors */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                اللون الرئيسي
              </label>
              <input
                type="color"
                name="primary_color"
                value={form.primary_color}
                onChange={handleChange}
                className="w-full h-12 rounded-xl border border-slate-200 cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                اللون الثانوي
              </label>
              <input
                type="color"
                name="secondary_color"
                value={form.secondary_color}
                onChange={handleChange}
                className="w-full h-12 rounded-xl border border-slate-200 cursor-pointer"
              />
            </div>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 text-sm px-4 py-3 rounded-xl">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold py-4 rounded-xl transition disabled:opacity-60 text-lg"
          >
            {loading ? (
              <Loader2 className="animate-spin" size={22} />
            ) : (
              'إنشاء المحل'
            )}
          </button>
        </form>
      </main>
    </div>
  );
}
