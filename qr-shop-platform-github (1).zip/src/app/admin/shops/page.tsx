import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';
import Link from 'next/link';
import { Plus, Store } from 'lucide-react';
import { AdminHeader } from '@/components/AdminHeader';
import { ShopsTable } from '@/components/ShopsTable';
import type { Shop } from '@/types';

export default async function ShopsPage() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect('/admin/login');

  const { data: shops } = await supabase
    .from('shops')
    .select('*')
    .order('created_at', { ascending: false });

  // Get view counts
  const { data: events } = await supabase
    .from('analytics_events')
    .select('shop_id, event_type');

  const viewCounts: Record<string, number> = {};
  (events || []).forEach((e) => {
    if (e.event_type === 'page_view') {
      viewCounts[e.shop_id] = (viewCounts[e.shop_id] || 0) + 1;
    }
  });

  const shopsWithViews = (shops || []).map((s: Shop) => ({
    ...s,
    page_views: viewCounts[s.id] || 0,
  }));

  return (
    <div className="min-h-screen bg-slate-50">
      <AdminHeader />

      <main className="max-w-6xl mx-auto px-4 py-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <Store size={28} className="text-teal-600" />
              المحلات
            </h1>
            <p className="text-slate-500 text-sm mt-1">
              {shopsWithViews.length} محل
            </p>
          </div>
          <Link
            href="/admin/shops/new"
            className="inline-flex items-center gap-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold px-5 py-3 rounded-xl transition shadow-sm"
          >
            <Plus size={20} />
            إضافة محل جديد
          </Link>
        </div>

        <ShopsTable shops={shopsWithViews} />
      </main>
    </div>
  );
}
