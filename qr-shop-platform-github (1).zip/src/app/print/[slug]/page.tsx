'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { QRCodeCanvas } from 'qrcode.react';
import { createClient } from '@/lib/supabase/client';
import { Printer, Loader2 } from 'lucide-react';
import type { Shop } from '@/types';
import { getAppUrl } from '@/lib/utils';

export default function PrintPage() {
  const params = useParams();
  const slug = params.slug as string;
  const [shop, setShop] = useState<Shop | null>(null);
  const [loading, setLoading] = useState(true);
  const supabase = createClient();

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from('shops')
        .select('*')
        .eq('slug', slug)
        .single();
      setShop(data);
      setLoading(false);
    }
    load();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-teal-600" size={32} />
      </div>
    );
  }

  if (!shop) {
    return <div className="text-center py-20">المحل غير موجود</div>;
  }

  const url = `${getAppUrl()}/shop/${shop.slug}`;

  return (
    <div className="min-h-screen bg-white">
      {/* Print button - hidden on print */}
      <div className="no-print p-4 text-center border-b">
        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-2 bg-teal-600 text-white px-6 py-3 rounded-xl font-semibold"
        >
          <Printer size={20} />
          طباعة
        </button>
      </div>

      {/* Print Area */}
      <div className="print-area flex flex-col items-center justify-center min-h-[80vh] p-8">
        {shop.logo_url && (
          <img
            src={shop.logo_url}
            alt={shop.name}
            className="w-24 h-24 object-contain mb-4 rounded-xl"
          />
        )}

        <h1 className="text-3xl font-bold text-slate-900 mb-2 text-center">
          {shop.name}
        </h1>

        <div className="my-6 p-4 bg-white border-2 border-slate-200 rounded-2xl">
          <QRCodeCanvas
            value={url}
            size={240}
            level="H"
            includeMargin
          />
        </div>

        <p className="text-lg text-slate-700 font-medium text-center">
          امسح الكود واكتشف خدماتنا
        </p>

        {shop.phone && (
          <p className="text-sm text-slate-500 mt-3 dir-ltr">{shop.phone}</p>
        )}
      </div>
    </div>
  );
}
