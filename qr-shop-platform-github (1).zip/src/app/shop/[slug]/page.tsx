import { notFound } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { ShopPageClient } from './ShopPageClient';
import type { Shop } from '@/types';

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: PageProps) {
  const { slug } = await params;
  const supabase = await createClient();
  const { data: shop } = await supabase
    .from('shops')
    .select('name, description')
    .eq('slug', slug)
    .eq('status', 'active')
    .single();

  if (!shop) {
    return { title: 'المحل غير موجود' };
  }

  return {
    title: `${shop.name} | منصة QR`,
    description: shop.description || `صفحة ${shop.name}`,
  };
}

export default async function ShopPage({ params }: PageProps) {
  const { slug } = await params;
  const supabase = await createClient();

  const { data: shop, error } = await supabase
    .from('shops')
    .select('*')
    .eq('slug', slug)
    .eq('status', 'active')
    .single();

  if (error || !shop) {
    notFound();
  }

  return <ShopPageClient shop={shop as Shop} />;
}
