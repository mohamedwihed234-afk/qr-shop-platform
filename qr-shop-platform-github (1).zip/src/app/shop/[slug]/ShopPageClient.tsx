'use client';

import { useEffect } from 'react';
import {
  Star,
  MessageCircle,
  Phone,
  Instagram,
  Facebook,
  MapPin,
  Menu,
  Camera,
  Music2,
} from 'lucide-react';
import type { Shop, EventType } from '@/types';
import { formatWhatsAppLink, formatPhoneLink } from '@/lib/utils';

interface Props {
  shop: Shop;
}

export function ShopPageClient({ shop }: Props) {
  useEffect(() => {
    // Track page view
    trackEvent('page_view');
  }, [shop.id]);

  async function trackEvent(eventType: EventType) {
    try {
      await fetch('/api/analytics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          shop_id: shop.id,
          event_type: eventType,
          device_type: /mobile|android|iphone/i.test(navigator.userAgent)
            ? 'mobile'
            : 'desktop',
        }),
      });
    } catch {
      // silent fail
    }
  }

  const primary = shop.primary_color || '#0f766e';
  const secondary = shop.secondary_color || '#14b8a6';

  const buttons = [
    {
      key: 'google_review_url',
      label: 'قيّم تجربتك على Google',
      icon: Star,
      color: '#f59e0b',
      href: shop.google_review_url,
      event: 'google_click' as EventType,
    },
    {
      key: 'whatsapp',
      label: 'تواصل معنا على واتساب',
      icon: MessageCircle,
      color: '#22c55e',
      href: shop.whatsapp ? formatWhatsAppLink(shop.whatsapp) : null,
      event: 'whatsapp_click' as EventType,
    },
    {
      key: 'phone',
      label: 'اتصل بنا',
      icon: Phone,
      color: '#3b82f6',
      href: shop.phone ? formatPhoneLink(shop.phone) : null,
      event: 'phone_click' as EventType,
    },
    {
      key: 'instagram_url',
      label: 'إنستغرام',
      icon: Instagram,
      color: '#e1306c',
      href: shop.instagram_url,
      event: 'instagram_click' as EventType,
    },
    {
      key: 'facebook_url',
      label: 'فيسبوك',
      icon: Facebook,
      color: '#1877f2',
      href: shop.facebook_url,
      event: 'facebook_click' as EventType,
    },
    {
      key: 'snapchat_url',
      label: 'سناب شات',
      icon: Camera,
      color: '#fffc00',
      href: shop.snapchat_url,
      event: 'snapchat_click' as EventType,
      textColor: '#000',
    },
    {
      key: 'tiktok_url',
      label: 'تيك توك',
      icon: Music2,
      color: '#000000',
      href: shop.tiktok_url,
      event: 'tiktok_click' as EventType,
    },
    {
      key: 'google_maps_url',
      label: 'موقعنا على الخريطة',
      icon: MapPin,
      color: '#ef4444',
      href: shop.google_maps_url,
      event: 'maps_click' as EventType,
    },
    {
      key: 'menu_url',
      label: 'المنيو',
      icon: Menu,
      color: '#8b5cf6',
      href: shop.menu_url,
      event: 'menu_click' as EventType,
    },
  ].filter((b) => b.href);

  return (
    <div
      className="min-h-screen flex flex-col"
      style={{
        background: `linear-gradient(180deg, ${primary}15 0%, #f8fafc 40%)`,
      }}
    >
      {/* Cover / Header */}
      <div className="relative">
        {shop.cover_url ? (
          <div className="h-40 sm:h-52 w-full overflow-hidden">
            <img
              src={shop.cover_url}
              alt=""
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          </div>
        ) : (
          <div
            className="h-32 sm:h-40"
            style={{ background: `linear-gradient(135deg, ${primary}, ${secondary})` }}
          />
        )}

        {/* Logo */}
        <div className="absolute left-1/2 -translate-x-1/2 -bottom-12 sm:-bottom-14">
          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-white shadow-xl border-4 border-white overflow-hidden flex items-center justify-center">
            {shop.logo_url ? (
              <img
                src={shop.logo_url}
                alt={shop.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <span
                className="text-3xl font-bold"
                style={{ color: primary }}
              >
                {shop.name.charAt(0)}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 px-4 pt-16 sm:pt-20 pb-10 max-w-md mx-auto w-full">
        {/* Name & Description */}
        <div className="text-center mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
            {shop.name}
          </h1>
          {shop.description && (
            <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
              {shop.description}
            </p>
          )}
          {shop.address && (
            <p className="text-slate-500 text-xs mt-2 flex items-center justify-center gap-1">
              <MapPin size={14} />
              {shop.address}
            </p>
          )}
          {shop.opening_hours && (
            <p className="text-slate-500 text-xs mt-1">
              🕐 {shop.opening_hours}
            </p>
          )}
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          {buttons.map((btn) => {
            const Icon = btn.icon;
            return (
              <a
                key={btn.key}
                href={btn.href!}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => trackEvent(btn.event)}
                className="flex items-center gap-4 w-full p-4 rounded-2xl shadow-md active:scale-[0.98] transition-all duration-150 hover:shadow-lg"
                style={{
                  backgroundColor: btn.color,
                  color: (btn as any).textColor || '#fff',
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.2)',
                  }}
                >
                  <Icon size={24} strokeWidth={2.2} />
                </div>
                <span className="font-semibold text-base sm:text-lg flex-1 text-right">
                  {btn.label}
                </span>
              </a>
            );
          })}
        </div>

        {buttons.length === 0 && (
          <div className="text-center text-slate-500 py-10">
            لا توجد روابط متاحة حالياً
          </div>
        )}

        {/* Footer */}
        <div className="mt-10 text-center text-xs text-slate-400">
          مدعوم بواسطة منصة QR للمحلات
        </div>
      </div>
    </div>
  );
}
