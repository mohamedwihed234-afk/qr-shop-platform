import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-slate-50 px-4 text-center">
      <h1 className="text-4xl font-bold text-slate-900 mb-2">404</h1>
      <p className="text-slate-600 mb-6">المحل غير موجود أو تم تعطيله</p>
      <Link
        href="/"
        className="bg-teal-600 text-white px-6 py-3 rounded-xl font-medium"
      >
        العودة
      </Link>
    </div>
  );
}
