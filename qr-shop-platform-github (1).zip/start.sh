#!/bin/bash
# ============================================
# منصة QR للمحلات — تشغيل بضغطة واحدة
# ============================================

cd "$(dirname "$0")"

echo ""
echo "========================================"
echo "   منصة QR للمحلات — جاري التشغيل..."
echo "========================================"
echo ""

# Check Node
if ! command -v node &> /dev/null; then
  echo "❌ Node.js غير مثبت. حمله من: https://nodejs.org"
  exit 1
fi

# Install if needed
if [ ! -d "node_modules" ] || [ ! -f "node_modules/.package-lock.json" ]; then
  echo "📦 تثبيت الحزم لأول مرة (قد يستغرق دقيقة)..."
  npm install --no-audit --no-fund
  echo ""
fi

# Check .env.local
if [ ! -f ".env.local" ]; then
  echo "⚠️  ملف .env.local غير موجود"
  echo "   انسخ .env.example إلى .env.local واملأ بيانات Supabase"
  echo ""
  if [ -f ".env.example" ]; then
    cp .env.example .env.local
    echo "   تم إنشاء .env.local من المثال — عدّله الآن"
  fi
  echo ""
fi

echo "🚀 تشغيل السيرفر..."
echo "   افتح المتصفح على: http://localhost:3000"
echo "   للهاتف على نفس الشبكة: استخدم IP جهازك"
echo ""
echo "   للإيقاف: اضغط Ctrl+C"
echo "========================================"
echo ""

npm run dev
