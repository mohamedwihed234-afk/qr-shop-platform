-- QR Shop Platform - Database Schema (MVP)
-- Run this in Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Shops table
CREATE TABLE IF NOT EXISTS shops (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  logo_url TEXT,
  cover_url TEXT,
  description TEXT,
  phone TEXT,
  whatsapp TEXT,
  instagram_url TEXT,
  facebook_url TEXT,
  snapchat_url TEXT,
  tiktok_url TEXT,
  google_maps_url TEXT,
  google_review_url TEXT,
  menu_url TEXT,
  address TEXT,
  opening_hours TEXT,
  primary_color TEXT DEFAULT '#0f766e',
  secondary_color TEXT DEFAULT '#14b8a6',
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Analytics events table
CREATE TABLE IF NOT EXISTS analytics_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  shop_id UUID NOT NULL REFERENCES shops(id) ON DELETE CASCADE,
  event_type TEXT NOT NULL CHECK (event_type IN (
    'page_view',
    'google_click',
    'whatsapp_click',
    'phone_click',
    'instagram_click',
    'facebook_click',
    'snapchat_click',
    'tiktok_click',
    'maps_click',
    'menu_click'
  )),
  device_type TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_shops_slug ON shops(slug);
CREATE INDEX IF NOT EXISTS idx_shops_status ON shops(status);
CREATE INDEX IF NOT EXISTS idx_analytics_shop_id ON analytics_events(shop_id);
CREATE INDEX IF NOT EXISTS idx_analytics_event_type ON analytics_events(event_type);
CREATE INDEX IF NOT EXISTS idx_analytics_created_at ON analytics_events(created_at);

-- Updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_shops_updated_at ON shops;
CREATE TRIGGER update_shops_updated_at
  BEFORE UPDATE ON shops
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Row Level Security (RLS)
ALTER TABLE shops ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY;

-- Public can read active shops
CREATE POLICY "Public can view active shops"
  ON shops FOR SELECT
  USING (status = 'active');

-- Public can insert analytics events
CREATE POLICY "Public can insert analytics"
  ON analytics_events FOR INSERT
  WITH CHECK (true);

-- Authenticated users (admin) full access to shops
CREATE POLICY "Authenticated users full access to shops"
  ON shops FOR ALL
  USING (auth.role() = 'authenticated')
  WITH CHECK (auth.role() = 'authenticated');

-- Authenticated users can read analytics
CREATE POLICY "Authenticated users can read analytics"
  ON analytics_events FOR SELECT
  USING (auth.role() = 'authenticated');

-- Sample seed data (optional - for testing)
-- INSERT INTO shops (slug, name, description, phone, whatsapp, google_review_url, google_maps_url, primary_color)
-- VALUES (
--   'elite-restaurant',
--   'مطعم النخبة',
--   'مطعم يقدم وجبات متنوعة وخدمة سريعة في قلب طرابلس.',
--   '0912345678',
--   '0912345678',
--   'https://g.page/r/example-review',
--   'https://maps.google.com/?q=Tripoli',
--   '#0f766e'
-- );
