@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo ========================================
echo    منصة QR للمحلات — جاري التشغيل...
echo ========================================
echo.

where node >nul 2>&1
if %errorlevel% neq 0 (
  echo Node.js غير مثبت. حمله من: https://nodejs.org
  pause
  exit /b 1
)

if not exist "node_modules" (
  echo تثبيت الحزم لأول مرة...
  call npm install --no-audit --no-fund
  echo.
)

if not exist ".env.local" (
  echo ملف .env.local غير موجود
  if exist ".env.example" (
    copy ".env.example" ".env.local" >nul
    echo تم إنشاء .env.local — عدّله ببيانات Supabase
  )
  echo.
)

echo تشغيل السيرفر...
echo افتح: http://localhost:3000
echo.
echo للإيقاف: اضغط Ctrl+C
echo ========================================
echo.

call npm run dev
pause
